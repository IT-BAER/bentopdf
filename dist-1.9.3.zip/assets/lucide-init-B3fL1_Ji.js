import{m as e,n}from"./index-Cb49Gzvg.js";document.addEventListener("DOMContentLoaded",()=>{e({icons:n})});
